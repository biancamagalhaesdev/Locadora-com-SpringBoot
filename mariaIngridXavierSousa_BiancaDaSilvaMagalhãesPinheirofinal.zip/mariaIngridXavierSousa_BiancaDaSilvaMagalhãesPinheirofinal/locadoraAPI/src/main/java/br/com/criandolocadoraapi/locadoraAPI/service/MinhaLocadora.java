package br.com.criandolocadoraapi.locadoraAPI.service;

import br.com.criandolocadoraapi.locadoraAPI.DAO.ICliente;
import br.com.criandolocadoraapi.locadoraAPI.DAO.IRegistroAluguel;
import br.com.criandolocadoraapi.locadoraAPI.DAO.IVeiculo;
import br.com.criandolocadoraapi.locadoraAPI.Excecoes.*;
import br.com.criandolocadoraapi.locadoraAPI.model.Cliente;
import br.com.criandolocadoraapi.locadoraAPI.model.RegistroAluguel;
import br.com.criandolocadoraapi.locadoraAPI.model.Veiculo;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.time.Duration;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Optional;
@Service
public class MinhaLocadora implements Locadora {

    @Autowired
    private IVeiculo dao;
    @Autowired
    private ICliente clienteDao;
    @Autowired
    private IRegistroAluguel registroDao;


    @Override // garante que o metodo ta de acordo com a interface
    public void inserir(Veiculo v) throws VeiculoJaCadastrado {
        if (dao.existsById(v.getPlaca())) {
            throw new VeiculoJaCadastrado(v.getPlaca());
        }
        dao.save(v);
    }

    @Override // garante que o metodo ta de acordo com a interface
    public void inserir(Cliente c) throws ClienteJaCadastrado {
        if (clienteDao.existsById((c.getCpf()))) {
            throw new ClienteJaCadastrado();
        }
        clienteDao.save(c);
    }

    @Override
    public Veiculo pesquisar(String placa) throws VeiculoNaoCadastrado {
        Optional<Veiculo> veiculoOpt = dao.findById(placa);
        if (veiculoOpt.isEmpty()) {
            throw new VeiculoNaoCadastrado(placa);
        } else {
            return veiculoOpt.get();
        }

    }

    public Cliente pesquisarCliente(int cpf) throws ClienteNaoCadastrado {
        return clienteDao.findById(cpf).orElseThrow(() -> new ClienteNaoCadastrado(cpf));
    }

    @Override
    public ArrayList<Veiculo> pesquisarMoto(int cilindrada) {
        try {
            return (ArrayList<Veiculo>) dao.findByTipoAndCilindradaGreaterThanEqual("Moto", cilindrada);
        } catch (Exception e) {
            throw new RuntimeException("Erro ao pesquisar motos", e);
        }
    }

    @Override
    public ArrayList<Veiculo> pesquisarCarro(int autonomia) {
        try {
            return (ArrayList<Veiculo>) dao.findByTipoAndAutonomiaGreaterThanEqual("Carro", autonomia);
        } catch (Exception e) {
            throw new RuntimeException("Erro ao pesquisar motos", e);
        }
    }

    @Override
    public ArrayList<Veiculo> pesquisarCaminhao(int capacCarga) {
        try {
            return (ArrayList<Veiculo>) dao.findByTipoAndCapacCargaGreaterThanEqual("Caminhao", capacCarga);
        } catch (Exception e) {
            throw new RuntimeException("Erro ao pesquisar caminhões", e);
        }
    }

    @Override
    public ArrayList<Veiculo> pesquisarOnibus(int capacPassageiros) {
        try {
            return (ArrayList<Veiculo>) dao.findByTipoAndCapacPassageirosGreaterThanEqual("Onibus", capacPassageiros);
        } catch (Exception e) {
            throw new RuntimeException("Erro ao pesquisar ônibus", e);
        }
    }

    @Override
    public double calcularAluguel(String placa, int dias) throws VeiculoNaoCadastrado {
        Veiculo veiculo = dao.findById(placa).orElseThrow(() -> new VeiculoNaoCadastrado(placa));
        return veiculo.calcularAluguel(dias);
    }
    @Override
    public void registrarAluguel(String placa, Date data, int dias, int cpf) throws VeiculoNaoCadastrado, VeiculoAlugado, ClienteNaoCadastrado {
        Veiculo v = dao.findByPlaca(placa);
        Cliente c = clienteDao.findByCpf(cpf);
        if (v == null) {
            throw new VeiculoNaoCadastrado(placa);
        }
        if (c == null) {
            throw new ClienteNaoCadastrado(cpf);
        }

        List<RegistroAluguel> alugueisAtivos = registroDao.findAllByVeiculo_Placa(placa);
        for (RegistroAluguel aluguel : alugueisAtivos) {
            if (aluguel.getData_devolucao() == null) {
                throw new VeiculoAlugado();
            }
        }

        RegistroAluguel a = new RegistroAluguel();
        a.setVeiculo(v);
        a.setCliente(c);
        a.setDias(dias);
        a.setData(data);
        a.setData_devolucao(null);
        registroDao.save(a);
    }

    public String registrarDevolucao(String placa, Date data, int cpf) throws VeiculoNaoCadastrado, VeiculoNaoAlugado, ClienteNaoCadastrado {
        Veiculo v = dao.findByPlaca(placa);
        Cliente c = clienteDao.findByCpf(cpf);
        if (v == null) {
            throw new VeiculoNaoCadastrado(placa);
        }
        if (c == null) {
            throw new ClienteNaoCadastrado(cpf);
        }
        List<RegistroAluguel> registros = registroDao.findAllByVeiculo_Placa(placa);
        if (registros.isEmpty()) {
            throw new VeiculoNaoAlugado(); // nenhum aluguel encontrado
        }

        for (RegistroAluguel ra : registros) {
            if (ra.getData_devolucao() == null) {
                ra.setData_devolucao(data);

                long diasAlugados = Duration.between(ra.getData().toInstant(), data.toInstant()).toDays();
                diasAlugados = Math.max(diasAlugados, 1); // Evita 0 dias, caso sejam iguais
                if (ra.getDias() != diasAlugados) {
                    ra.setDias((int) diasAlugados);
                }

                Veiculo veiculo = dao.findById(placa).orElseThrow();
                double faturamento = diasAlugados * veiculo.getVal_diaria();

                ra.setFaturamento(faturamento);
                registroDao.save(ra);

                return "Veículo devolvido com sucesso";
            }
        }
        //se não, ja foi devolvido antes
        return "Veículo já foi devolvido";
    }

    @Override
    public String depreciarVeiculos(int tipo, float taxaDepreciacao) {
        List<Veiculo> veiculos;
        String stipo = "";
        if (tipo == 1) {
            stipo = "Moto";
        } else if (tipo == 2) {
            stipo = "Carro";
        } else if (tipo == 3) {
            stipo = "Caminhao";
        } else if (tipo == 4) {
            stipo = "Onibus";
        } else {
            stipo = null;
        }
        if (stipo != null) {
            veiculos = dao.findByTipo(stipo);
        } else {
            veiculos = (List<Veiculo>) dao.findAll(); // deprecia todos
        }
        for (Veiculo v : veiculos) {
            float novoValor = v.getVal_bem() * (1 - taxaDepreciacao);
            v.setVal_bem(novoValor);
            dao.save(v);
        }
        if(stipo != null) {
            return "Veículos do tipo " + stipo + " depreciados com sucesso.";
        }else{
            return "Todos os veiculos foram depreciados.";
        }
    }

    @Override
    public String aumentarDiaria(int tipo, float taxaAumento) {
        List<Veiculo> veiculos;
        String stipo = "";

        if (tipo == 1) {
            stipo = "Moto";
        } else if (tipo == 2) {
            stipo = "Carro";
        } else if (tipo == 3) {
            stipo = "Caminhao";
        } else if (tipo == 4) {
            stipo = "Onibus";
        } else {
            stipo = null;
        }

        if (stipo != null) {
            veiculos = dao.findByTipo(stipo);
        } else {
            veiculos = (List<Veiculo>) dao.findAll();
        }

        for (Veiculo v : veiculos) {
            float novoValor = v.getVal_diaria() * (1 + taxaAumento);
            v.setVal_diaria(novoValor);
            dao.save(v);
        }

        if (stipo != null) {
            return "Diária dos veículos do tipo " + stipo + " aumentada com sucesso.";
        } else {
            return "Diária de todos os veículos aumentada com sucesso.";
        }
    }

    @Override
    public String faturamentoTotal(String stipo, Date inicio, Date fim) {
        double valor = registroDao.faturamentoTotal(stipo,inicio,fim);
        if (stipo != null) {
            return "Faturamento total dos veículos do tipo " + stipo + "é igual a " + valor + ".";
        } else {
            return "Faturamento total de todos os veículos é igual a " + valor + ".";
        }
    }

    @Override
    public String quantidadeTotalDeDiarias(String stipo, Date inicio, Date fim) {
        int dias = registroDao.quantidadeTotalDeDiarias(stipo,inicio,fim);
        if (stipo != null) {
            return "Quantidade total de diárias dos veículos do tipo " + stipo + "é igual a " + dias + ".";
        } else {
            return "Quantidade total de diárias de todos os veículos é igual a " + dias + ".";
        }
    }

    @Override
    public void removerTudo() {
        registroDao.deleteAll();
        dao.deleteAll();
        clienteDao.deleteAll();
    }

}
