package br.com.criandolocadoraapi.locadoraAPI.Excecoes;

public class VeiculoAlugado extends Exception {
    public VeiculoAlugado(){
        super("O veiculo ja foi alugado.");
    }
}
