package br.com.criandolocadoraapi.locadoraAPI.DAO;
import br.com.criandolocadoraapi.locadoraAPI.model.Cliente;
import org.springframework.data.repository.CrudRepository;

public interface ICliente extends CrudRepository<Cliente,Integer> {

    Cliente findByCpf(int cpf);
}
