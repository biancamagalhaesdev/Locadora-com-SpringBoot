package br.com.criandolocadoraapi.locadoraAPI.controller;

import br.com.criandolocadoraapi.locadoraAPI.DAO.ICliente;
import br.com.criandolocadoraapi.locadoraAPI.DAO.IRegistroAluguel;
import br.com.criandolocadoraapi.locadoraAPI.DAO.IVeiculo;
import br.com.criandolocadoraapi.locadoraAPI.Excecoes.*;
import br.com.criandolocadoraapi.locadoraAPI.model.RegistroAluguel;
import br.com.criandolocadoraapi.locadoraAPI.service.MinhaLocadora;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;
import org.springframework.format.annotation.DateTimeFormat;

import java.util.Date;
import java.util.List;
import java.util.Optional;


@RestController
@RequestMapping("/registrosalugueis")
public class RegistroAluguelController {
    private final MinhaLocadora locadora;
    private final ICliente daoCliente;
    private final IVeiculo daoVeiculo;
    private final IRegistroAluguel dao;

    @Autowired
    public RegistroAluguelController(MinhaLocadora locadora, ICliente daoCliente, IVeiculo daoVeiculo, IRegistroAluguel dao) {
        this.locadora = locadora;
        this.daoCliente = daoCliente;
        this.daoVeiculo = daoVeiculo;
        this.dao = dao;
    }

    @GetMapping
    public List<RegistroAluguel> listaRegistroAluguel(){
        return (List<RegistroAluguel>) dao.findAll();
    }
    @PostMapping
    public String criarRegistroAluguel(@RequestBody RegistroAluguel registro) throws VeiculoAlugado, VeiculoNaoCadastrado, ClienteNaoCadastrado {
        try {
            locadora.registrarAluguel(registro.getVeiculo().getPlaca(), registro.getData(), registro.getDias(), registro.getCliente().getCpf());
            return "Veiculo alugado com sucesso";
        } catch (Exception e) {
            return "Erro: " + e.getMessage();
        }

    }
    @PutMapping("/devolucao")
    public String registrarDevolução(@RequestParam String placa,
                                     @RequestParam @DateTimeFormat(iso = DateTimeFormat.ISO.DATE) Date dataDevolucao,
                                     @RequestParam int cpf){
        try {
            return locadora.registrarDevolucao(placa, dataDevolucao, cpf);
        } catch (Exception e) {
            return "Erro: " + e.getMessage();
        }
    }

    @GetMapping("/faturamentototal")
    public String faturamentoTotal(
            @RequestParam int tipo,
            @RequestParam @DateTimeFormat(iso = DateTimeFormat.ISO.DATE) Date inicio,
            @RequestParam(required = false) @DateTimeFormat(iso = DateTimeFormat.ISO.DATE) Date fim
    ) {
        String tipoVeiculo = null;
        switch (tipo) {
            case 1: tipoVeiculo = "Moto"; break;
            case 2: tipoVeiculo = "Carro"; break;
            case 3: tipoVeiculo = "Caminhao"; break;
            case 4: tipoVeiculo = "Onibus"; break;
            default: tipoVeiculo = null; // Sem filtro por tipo
        }
        return locadora.faturamentoTotal(tipoVeiculo, inicio, fim);
    }
    @GetMapping("/diariatotal")
    public String diariaTotal(
            @RequestParam int tipo,
            @RequestParam @DateTimeFormat(iso = DateTimeFormat.ISO.DATE) Date inicio,
            @RequestParam(required = false) @DateTimeFormat(iso = DateTimeFormat.ISO.DATE) Date fim
    ) {
        String tipoVeiculo = null;
        switch (tipo) {
            case 1: tipoVeiculo = "Moto"; break;
            case 2: tipoVeiculo = "Carro"; break;
            case 3: tipoVeiculo = "Caminhao"; break;
            case 4: tipoVeiculo = "Onibus"; break;
            default: tipoVeiculo = null; // Sem filtro por tipo
        }
        return locadora.quantidadeTotalDeDiarias(tipoVeiculo, inicio, fim);
    }

    @DeleteMapping("/{id}")
    public Optional<RegistroAluguel> excluirRegistroAluguel (@PathVariable Integer id){
        Optional<RegistroAluguel> registroAluguel = dao.findById(id);
        dao.deleteById(id);
        return registroAluguel;
    }

}

