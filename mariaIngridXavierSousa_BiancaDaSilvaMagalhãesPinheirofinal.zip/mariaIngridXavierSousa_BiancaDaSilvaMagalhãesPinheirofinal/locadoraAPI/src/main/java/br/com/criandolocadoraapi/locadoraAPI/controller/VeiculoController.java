package br.com.criandolocadoraapi.locadoraAPI.controller;

import br.com.criandolocadoraapi.locadoraAPI.Excecoes.VeiculoJaCadastrado;
import br.com.criandolocadoraapi.locadoraAPI.DAO.IVeiculo;
import br.com.criandolocadoraapi.locadoraAPI.Excecoes.VeiculoNaoCadastrado;
import br.com.criandolocadoraapi.locadoraAPI.model.Veiculo;
import br.com.criandolocadoraapi.locadoraAPI.service.MinhaLocadora;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Optional;

@RestController
@RequestMapping("/veiculos")
public class VeiculoController {
    private final MinhaLocadora locadora;

    public VeiculoController(MinhaLocadora locadora) {
        this.locadora = locadora;
    }
    @Autowired
    private IVeiculo dao;
    @GetMapping
    public List<Veiculo> listaVeiculos(){
        return (List<Veiculo>) dao.findAll();
    }
    @PostMapping
    public String inserirVeiculo(@RequestBody Veiculo veiculo) {
        try {
            locadora.inserir(veiculo);
            return "Veículo inserido com sucesso";
        } catch (VeiculoJaCadastrado e) {
            return "Erro: " + e.getMessage();
        }
    }
    @GetMapping("/{placa}")
    public ResponseEntity<?> pesquisarVeiculo(@PathVariable String placa) {
        try {
            Veiculo veiculo = locadora.pesquisar(placa);
            return ResponseEntity.ok(veiculo);
        } catch (VeiculoNaoCadastrado e) {
            return ResponseEntity.status(HttpStatus.NOT_FOUND).body(e.getMessage());
        }
    }

    @GetMapping("/motos")
    public List<Veiculo> pesquisarMotos(@RequestParam int cilindrada) {
        return locadora.pesquisarMoto(cilindrada);
    }
    @GetMapping("/carros")
    public List<Veiculo> pesquisarCarros(@RequestParam int autonomia) {
        return locadora.pesquisarCarro(autonomia);
    }
    @GetMapping("/caminhoes")
    public List<Veiculo> pesquisarCaminhoes(@RequestParam int cargaMinima) {
        return locadora.pesquisarCaminhao(cargaMinima);
    }

    @GetMapping("/onibus")
    public List<Veiculo> pesquisarOnibus(@RequestParam int passageirosMinimos) {
        return locadora.pesquisarOnibus(passageirosMinimos);
    }
    @GetMapping("/calculoaluguel")
    public ResponseEntity<String> calcularAluguel(
            @RequestParam String placa,
            @RequestParam int dias) {
        try {
            double valor = locadora.calcularAluguel(placa, dias);
            return ResponseEntity.ok("Valor do aluguel para o veículo " + placa + ": R$ " + valor);
        } catch (VeiculoNaoCadastrado e) {
            return ResponseEntity.status(HttpStatus.NOT_FOUND)
                    .body("Veículo não cadastrado. Placa: " + placa);
        } catch (Exception e) {
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR)
                    .body("Erro ao calcular aluguel: " + e.getMessage());
        }
    }

    @PutMapping("/depreciarveiculos")
    public String depreciarVeiculos(@RequestParam int tipo, @RequestParam float taxa) {
        return locadora.depreciarVeiculos(tipo, taxa);
    }
    @PutMapping("/aumentardiaria")
    public String aumentarDiaria(@RequestParam int tipo, @RequestParam float taxa) {
        return locadora.aumentarDiaria(tipo, taxa);
    }
    @PutMapping
    public Veiculo editarVeiculo(@RequestBody Veiculo veiculo){
        Veiculo veiculoNovo = dao.save(veiculo);
        return veiculoNovo;
    }
    @DeleteMapping("/removertudo")
    public ResponseEntity<String> apagarTudo() {
        locadora.removerTudo();
        return ResponseEntity.ok("Todos os dados apagados.");
    }
    @DeleteMapping("/{placa}")
    public Optional<Veiculo> excluirVeiculo (@PathVariable String placa){
        Optional<Veiculo> veiculo = dao.findById(placa);
        dao.deleteById(placa);
        return veiculo;
    }

}
