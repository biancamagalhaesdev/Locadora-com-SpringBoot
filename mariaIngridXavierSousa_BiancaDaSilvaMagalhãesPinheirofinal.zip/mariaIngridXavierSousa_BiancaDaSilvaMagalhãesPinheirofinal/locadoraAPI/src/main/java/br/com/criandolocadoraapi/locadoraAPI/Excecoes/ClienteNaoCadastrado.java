package br.com.criandolocadoraapi.locadoraAPI.Excecoes;

public class ClienteNaoCadastrado extends Exception {
    public ClienteNaoCadastrado(int cpf){
        super("Cliente nao encontrado.");
    }
}
