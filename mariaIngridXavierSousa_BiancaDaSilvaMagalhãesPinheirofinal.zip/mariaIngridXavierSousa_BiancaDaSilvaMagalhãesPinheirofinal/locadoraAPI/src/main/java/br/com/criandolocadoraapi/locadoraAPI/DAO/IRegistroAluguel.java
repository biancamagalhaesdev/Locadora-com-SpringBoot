package br.com.criandolocadoraapi.locadoraAPI.DAO;

import br.com.criandolocadoraapi.locadoraAPI.model.RegistroAluguel;
import org.springframework.data.repository.CrudRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import java.util.Date;
import java.util.List;
import java.util.Optional;

public interface IRegistroAluguel extends CrudRepository<RegistroAluguel,Integer> {
    RegistroAluguel findByVeiculo_Placa(String placa);

    List<RegistroAluguel> findAllByVeiculo_Placa(String placa);

    Optional<RegistroAluguel> findByVeiculo_PlacaAndCliente_Cpf(String placa, int cpf);

    @Query("SELECT COALESCE(SUM(ra.faturamento), 0.0) " + //soma os faturamentos ou 0 se nao houver
            "FROM RegistroAluguel ra JOIN ra.veiculo v " + // Junta registros de aluguel com veículos pela associação
            "WHERE (:tipo IS NULL OR v.tipo = :tipo) " + // Filtra pelo tipo se informado se 1 a 4, senão todos
            "AND ra.data_devolucao >= :inicio " + // Data devolução maior ou igual a início
            "AND (:fim IS NULL OR ra.data_devolucao <= :fim)") // Data devolução menor ou igual a fim, se informado
    Double faturamentoTotal(@Param("tipo") String tipo,
                            @Param("inicio") Date inicio,
                            @Param("fim") Date fim);

    @Query("SELECT COALESCE(SUM(ra.dias), 0) " + // Soma total dos dias alugados, ou zero se não houver registros
            "FROM RegistroAluguel ra JOIN ra.veiculo v " + // Junta registro aluguel com veículo pela associação
            "WHERE (:tipo IS NULL OR v.tipo = :tipo) " + // Filtra pelo tipo se informado, senão todos
            "AND ra.data_devolucao >= :inicio " + // Considera registros com data devolução maior ou igual a início
            "AND (:fim IS NULL OR ra.data_devolucao <= :fim)") // Data devolução menor ou igual a fim, se informado
    Integer quantidadeTotalDeDiarias(@Param("tipo") String tipo,
                                     @Param("inicio") Date inicio,
                                     @Param("fim") Date fim);

}

