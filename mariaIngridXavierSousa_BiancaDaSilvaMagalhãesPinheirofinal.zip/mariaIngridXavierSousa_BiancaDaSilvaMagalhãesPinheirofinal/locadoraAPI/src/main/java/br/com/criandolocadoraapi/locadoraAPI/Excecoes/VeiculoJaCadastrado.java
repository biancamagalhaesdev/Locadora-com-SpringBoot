package br.com.criandolocadoraapi.locadoraAPI.Excecoes;

public class VeiculoJaCadastrado extends Exception {
    public VeiculoJaCadastrado(String p){
        super("Veiculo ja cadastrado. Placa: " + p);
    }
}
