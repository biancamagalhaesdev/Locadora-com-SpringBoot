package br.com.criandolocadoraapi.locadoraAPI.DAO;
import br.com.criandolocadoraapi.locadoraAPI.model.Veiculo;
import org.springframework.data.repository.CrudRepository;

import java.util.List;

public interface IVeiculo  extends CrudRepository<Veiculo,String>{
    List<Veiculo> findByTipoAndCilindradaGreaterThanEqual(String tipo, int cilindrada);
    List<Veiculo> findByTipoAndAutonomiaGreaterThanEqual(String tipo, int autonomia);
    List<Veiculo> findByTipoAndCapacCargaGreaterThanEqual(String tipo, float capacCarga);
    List<Veiculo> findByTipoAndCapacPassageirosGreaterThanEqual(String tipo, int capacPassageiros);
    Veiculo findByPlaca(String placa);

    List<Veiculo> findByTipo(String tipo);
}


