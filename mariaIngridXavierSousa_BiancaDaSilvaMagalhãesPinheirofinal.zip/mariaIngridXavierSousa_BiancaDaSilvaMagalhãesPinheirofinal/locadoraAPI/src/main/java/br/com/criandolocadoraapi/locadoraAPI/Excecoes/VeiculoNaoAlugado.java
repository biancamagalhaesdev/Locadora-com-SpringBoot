package br.com.criandolocadoraapi.locadoraAPI.Excecoes;

public class VeiculoNaoAlugado extends Exception {
    public VeiculoNaoAlugado(){
        super("Veiculo nao alugado.");
    }
}
