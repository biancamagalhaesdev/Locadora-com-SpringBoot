package br.com.criandolocadoraapi.locadoraAPI.controller;
import br.com.criandolocadoraapi.locadoraAPI.DAO.ICliente;
import br.com.criandolocadoraapi.locadoraAPI.Excecoes.ClienteJaCadastrado;
import br.com.criandolocadoraapi.locadoraAPI.model.Cliente;
import br.com.criandolocadoraapi.locadoraAPI.service.MinhaLocadora;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Optional;

@RestController
@RequestMapping("/clientes")
public class ClienteController  {
    private final MinhaLocadora locadora;
    private final ICliente dao;

    @Autowired
    public ClienteController(MinhaLocadora locadora, ICliente dao) {
        this.locadora = locadora;
        this.dao = dao;
    }

    @GetMapping
    public List<Cliente> listaClientes(){
        return (List<Cliente>) dao.findAll();
    }
    @PostMapping
    public String inserirCliente(@RequestBody Cliente cliente) {
        try {
            locadora.inserir(cliente);
            return "Cliente inserido com sucesso";
        } catch (ClienteJaCadastrado e) {
            return "Erro: " + e.getMessage();
        }
    }
    @PutMapping
    public Cliente editarCliente(@RequestBody Cliente cliente){
        Cliente clienteNovo = dao.save(cliente);
        return clienteNovo;
    }
    @DeleteMapping("/{cpf}")
    public Optional<Cliente> excluirCliente(@PathVariable int cpf){
        Optional<Cliente> cliente = dao.findById(cpf);
        dao.deleteById(cpf);
        return cliente;
    }
    @GetMapping("/{cpf}")
    public Optional<Cliente> pesquisarCliente(@PathVariable int cpf) {
        return dao.findById(cpf);
    }

}
