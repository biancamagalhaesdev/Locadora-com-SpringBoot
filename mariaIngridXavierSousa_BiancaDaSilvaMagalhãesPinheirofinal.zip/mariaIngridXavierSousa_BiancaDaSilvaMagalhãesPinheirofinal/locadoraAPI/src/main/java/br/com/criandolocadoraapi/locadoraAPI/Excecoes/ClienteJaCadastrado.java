package br.com.criandolocadoraapi.locadoraAPI.Excecoes;

public class ClienteJaCadastrado extends Exception {
    public ClienteJaCadastrado(){
        super("Cliente ja cadastrado.");
    }
}
