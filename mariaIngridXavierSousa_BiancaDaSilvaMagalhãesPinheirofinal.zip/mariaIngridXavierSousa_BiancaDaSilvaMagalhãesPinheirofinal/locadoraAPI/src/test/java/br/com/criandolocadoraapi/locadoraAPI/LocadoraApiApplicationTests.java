package br.com.criandolocadoraapi.locadoraAPI;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class LocadoraApiApplicationTests {

	@Test
	void contextLoads() {
	}

}
